//package com.excel.vbs.service;
//
//import com.excel.vbs.dto.CustomerRegDto;
//
//public interface CustomerService {
//
//   public String saveCustInfo(CustomerRegDto dto);
//
//}
