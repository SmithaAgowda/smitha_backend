package com.excel.vbs.service;


import com.excel.vbs.dto.PincodeDto;

public interface PincodeService {

	public String savePinInfo(PincodeDto dto);
	

}
