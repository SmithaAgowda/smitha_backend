//package com.excel.vbs.repository;
//
//
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//
//import com.excel.vbs.entity.CustomerReg;
//
//public interface CustomerRepository extends JpaRepository<CustomerReg, Integer>{
//	
//}
